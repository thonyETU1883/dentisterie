package com.example.dentisterie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DentisterieProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(DentisterieProjectApplication.class, args);
	}

}
